<?php 
//untuk ngecek, apakah ada atau tidak tipe get menu di URL browser, agar tidak muncul error 
//jika menu tidak di tulis
$menu=isset($_GET['menu'])?$_GET['menu']:"home";
?>
<link rel="stylesheet" href="fontawesome/css/all.min.css">
<nav  class="navbar navbar-expand-lg navbar-light fixed-top" style="background-color: #3c8dbc; box-shadow: 1px 0px 10px, -1px 0px 10px;">
  <a class="navbar-brand" href="?menu=home"> <i class="fa-solid fa-earth-asia"></i><b> SIUKM</b></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="icon ml-4">
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item <?=($menu=="home")?"active":""?>">
          <a class="nav-link" href="?menu=home"> <i class="fa-solid fa-house-chimney mr-2"></i> Beranda</a>
        </li>

        <li class="nav-item <?=($menu=="data_anggota_ukm")?"active":""?>">
          <a class="nav-link" href="?menu=data_anggota_ukm"><i class="fa-solid fa-folder"></i> Data UKM</a>
        </li>


    	  <!-- <li class="nav-item <?=($menu=="file")?"active":""?>">
          <a class="nav-link" href="?menu=file">File</a>
        </li> -->

        <li class="nav-item <?=($menu=="about")?"active":""?>">
          <a class="nav-link" href="?menu=about"><i class="fa-solid fa-address-card"></i> About</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="logout.php"><i class="fa-solid fa-right-from-bracket mr-1" data-toggle="tooltip" title="Sign Out"></i>Logout</a>
        </li>
    </ul>
  </div>
</nav>
<!-- nav -->
