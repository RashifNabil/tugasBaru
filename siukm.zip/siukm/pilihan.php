<?php

// Bagian Home
if ($menu=='home'){
	include "page/home/home.php";
}
// Bagian data ukm
elseif ($menu=='data_anggota_ukm'){
    include "page/data_anggota_ukm/data_anggota_ukm.php";   
}

// Bagian file
elseif ($menu=='file'){
    include "page/file/file.php";   
}
// Bagian About
else if($menu=='about'){
	include "page/about/about.php";
}
// Apabila modul tidak ditemukan
else{
  echo "<h4 class='text-center' style='margin-top:60px;'><b>PAGE BELUM ADA ATAU BELUM LENGKAP ATAU ANDA TIDAK BERHAK 
  MENGAKSES HALAMAN INI</b></h4>";
}
?>
