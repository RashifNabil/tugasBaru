<?php
session_start();
if (!empty($_SESSION['username'])){
  header("location:admin.php?menu=home");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="icon" type="jpg/png" href="gambar/garuda.jpg" sizes="16x16" />
	<link rel="stylesheet" href="style/login.css">
	<link rel="stylesheet" href="fontawesome/css/all.min.css">
	<title>Halaman Login SIUKM</title>
</head>
<body>

<div class="container">
		<form method="POST">
		<div class="thumbnail"><center><img src="gambar/house.png" height="100"/></center></div></a><p/>
			<div class="form-group">
				<label for="username">Username</label>
				<div class="input-group">
					<div class="input-group-prepend">
						<div class="input-group-text"><i class="fas fa-user"></i></div>
					</div>
					<input type="text" class="form-control" id="username" name="username" placeholder="Masukkan Username">
				</div>
			</div>
			<div class="form-group">
				<label for="password">Password</label>
				<div class="input-group">
					<div class="input-group-prepend">
						<div class="input-group-text"><i class="fa-solid fa-lock"></i></div>
					</div>
					<input type="password" class="form-control" id="password" name="password" placeholder="Masukkan Password">
				</div>
			</div>
			<button type="submit" name="login" class="btn btn-primary btn-block">Login</button>
			<p class="login-register-text">Anda belum punya akun? <a href="register.php">Register</a></p>
			<?php if(isset($_GET['login'])=="gagal"){?>
			<span class="help-block">Login Gagal</span>
			<?php } ?>
		</form>
			</div>
		<div class="col-sm-4">&nbsp;</div>
	</div><!-- end row -->
</div> <!-- end container -->


<?php 
include "./koneksi.php";
if(isset($_POST['login'])){ //jika tombol submit di klik
	$username = $_POST['username'];
	$pass     = md5($_POST['password']);
	$login=mysqli_query($koneksi,"SELECT * FROM tbl_login WHERE username='$username' AND password='$pass' AND status_login='0' ");
	$ketemu=mysqli_num_rows($login);
	
	$r=mysqli_fetch_array($login);
	// Apabila username dan password ditemukan
	if ($ketemu > 0){  
	  $_SESSION['username']     = $r['username'];
	  $_SESSION['nama_lengkap']  = $r['nama_lengkap'];
	  //update kolom status itu menjadi 1
	  header("location:admin.php?menu=home");
	}else{
	  header("location:index.php?login=gagal");
	}
}
?>

</body>
</html>