<?php
session_start();
if (empty($_SESSION['username'])){
  header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
	  <link rel="icon" type="image/png" href="gambar/garuda.jpg" sizes="16x16" />

	<?php 
	$aku="homessss";
	if($aku=="home"){
	?>
	<title></title>
	<?php } else { ?>
	<title>Data Pemilik UKM</title>
	<?php } ?>
	
</head>
<body class="mt-5">
  <?php
  include "menu.php";
  ?>
  <div class="container">
  <?php 
  include "pilihan.php";
  ?>
  </div> <!-- container -->
  <div class="mt-5"></div>
  <!-- Footer -->
  <footer>
    <!-- Copyright -->
    <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
      © 2022 Copyright:
      <a class="text-reset fw-bold" href="">MAHASISWA INFORMATIKA UNIRA</a>
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer End-->
  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.bundle.min.js"></script>

  <!-- Datatables -->
  <script src="assets/DataTables/DataTables-1.10.18/js/jquery.dataTables.min.js"></script>
  <script src="assets/DataTables/DataTables-1.10.18/js/dataTables.bootstrap4.min.js"></script>

  <script src="assets/DataTables/Buttons-1.5.6/js/dataTables.buttons.min.js"></script>
  <script src="assets/DataTables/Buttons-1.5.6/js/buttons.bootstrap4.min.js"></script>
  <script src="assets/DataTables/JSZip-2.5.0/jszip.min.js"></script>
  <script src="assets/DataTables/pdfmake-0.1.36/pdfmake.min.js"></script>
  <script src="assets/DataTables/pdfmake-0.1.36/vfs_fonts.js"></script>
  <script src="assets/DataTables/Buttons-1.5.6/js/buttons.html5.min.js"></script>
  <script src="assets/DataTables/Buttons-1.5.6/js/buttons.print.min.js"></script>
  <script src="assets/DataTables/Buttons-1.5.6/js/buttons.colVis.min.js"></script>
  <script>
    $(document).ready(function() {
      var table = $('#table').DataTable( {
          buttons: [ 'print', 'excel', 'pdf', 'colvis' ],
          dom:
          "<'row'<'col-md-3'l><'col-md-5'B><'col-md-4'f>>" +
          "<'row'<'col-md-12'tr>>" +
          "<'row'<'col-md-5'i><'col-md-7'p>>",
          lengthMenu:[
            [5,10,25,50,100,-1],
            [5,10,25,50,100,"All"]
          ]
      } );          
      table.buttons().container()
      .appendTo( '#table_wrapper .col-md-5:eq(0)' );
    } );
  </script>
</body>
</html>