<?php
include "koneksi.php";
$action=isset($_GET['submenu'])? $_GET['submenu'] :'';
switch($action){
default:
?>
<h3><i class="fa-solid fa-folder" style="margin-top:50px;"></i> Data UKM</h3><hr>

<div class="row">
	<div class="col-sm-12">
	 <div class="table-responsive ">
	 <table id="table" class="table table-striped table-bordered">
	 
	  <thead class="thead-dark">
		<center>
		<!-- <a href="?menu=data_anggota_ukm&submenu=tambah" class="btn btn-primary mb-2">Tambah Data </a> -->
		<a href="?menu=data_anggota_ukm&submenu=tambah" class="btn btn-primary btn-lg btn-block mb-3" style="margin-top:20px">Tambah Data</a>
		</center>
	  
		<tr class="text-center">
			<th class="align-middle">No</th>
			<th class="align-middle">Nama</th>
			<th class="align-middle">Alamat</th>
			<th class="align-middle">Kecamatan</th>
			<th class="align-middle">Usaha</th>
			<th class="align-middle">Jenis Usaha</th>
			<th class="align-middle">Modal</th>
			<th class="align-middle">Permasalahan</th>
			<th class="align-middle">Solusi</th>
			<th class="align-middle">Edit</th>
			<th class="align-middle">Delete</th>
		</tr>
	  </thead>
	  <tbody>
	<!-- cetak -->
	<?php 
	$query=mysqli_query($koneksi, "SELECT * FROM data_ukm ORDER BY nama asc");
	$no=1;
	while($d=mysqli_fetch_assoc($query)){ 
	//ini menghasilkan array associative
	?>
		<tr>
			<td><?= $no; ?></td>
			<td><?= $d['nama']; ?></td>
			<td><?= strtolower($d['alamat']); ?></td>
			<td><?= $d['kecamatan']; ?></td>
			<td><?= $d['usaha']; ?></td>
			<td><?= $d['jenis_usaha']; ?></td>
			<td><?= $d['modal']; ?></td>
			<td><?= $d['permasalahan']; ?></td>
			<td><?= $d['pemecahan']; ?></td>
			<td><a href="?menu=data_anggota_ukm&submenu=edit&id=<?= $d['id_data_ukm'];?>">Edit</a></td>
			<td>
				<a href="?menu=data_anggota_ukm&submenu=hapus&id=<?= $d['id_data_ukm'];?>" 
				onClick="return confirm('Yakin mau di hapus?');">Delete</a>
			</td>
		</tr>
	<?php 
	$no++;
	} 
	?>
	  </tbody>
	 </table>
	 </div> <!-- end div responsive -->
	</div>
	<!-- <a href="?menu=data_anggota_ukm&submenu=tambah" class="btn btn-primary mb-2" style="margin-top:30px;">Tambah Data </a> -->
	<div class="container">
		<center>
			<!-- <a href="admin.php?menu=home" class="btn btn-primary mb-2 "  style="margin-top:20px;"> Kembali </a> -->
			<a href="admin.php?menu=home" class="btn btn-secondary btn-lg btn-block" style="margin-top:20px">Kembali</a>
		</center>
	</div>
	
  </div> <!-- end row -->
 

<?php 
break;
case "tambah":
?>
<h1 style="margin-top:60px;"> <i class="fa-solid fa-file-plus-minus"></i> Tambah Data UKM</h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="admin.php?menu=data_anggota_ukm">Data UKM</a></li>
    <li class="breadcrumb-item active" aria-current="page">Input data</li>
  </ol>
</nav>

<hr/>
<div class="row">
	<div class="col-sm-4">
		<form method="POST">
			<div class="form-group">
				<label for="nama">Nama</label><br/>
				<input type="text" class="form-control" name="nama" id="nama" required placeholder="Tulis Nama" autocomplete="off" />
			</div>
			<div class="form-group">
				<label for="alamat">Alamat</label><br/>
				<input type="text" class="form-control"  name="alamat" id="alamat " required placeholder="Tulis Alamat"/>
			</div>
			<div class="form-group">
				<label for="kecamatan">Kecamatan</label><br/>
				<input type="text" class="form-control"  name="kecamatan" id="kecamatan" required placeholder="Tulis Kecamatan"/>
			</div>
			<div class="form-group">
				<label for="usaha">Usaha</label><br/>
				<input type="text" class="form-control"  name="usaha" id="usaha" required placeholder="Tulis Usaha"/>
			</div>
			<div class="form-group">
				<label for="jenis_usaha">Jenis Usaha</label><br/>
				<input type="text" class="form-control"  name="jenis_usaha" id="jenis_usaha" required placeholder="Tulis Jenis Usaha"/>
			</div>
			<div class="form-group">
				<label for="modal">Modal</label><br/>
				<input type="number" class="form-control" name="modal" id="modal" min="10000" max="1000000000000" required placeholder="Modal Minimal Rp10.000" required autocomplete="off"/>
			</div>
			<div class="form-group">
				<label for="permasalahan">Permasalahan</label><br/>
				<input type="text" class="form-control"  name="permasalahan" id="permasalahan" required placeholder="Tulis Permasalahan"/>
			</div>
			<div class="form-group">
				<label for="pemecahan">Solusi</label><br/>
				<input type="text" class="form-control"  name="pemecahan" id="pemecahan" required placeholder="Tulis Solusi"/>
			</div>
			<button type="submit" name="submit" class="btn btn-primary">Tambah Data</button>
			<a href="?menu=data_anggota_ukm" class="btn btn-info">Kembali</a>
		</form>
	</div>
</div> <!-- end row -->
<?php 
if(isset($_POST['submit'])){ //jika tombol submit di klik
	//ambil data dari form input
	//mengabaikan tanda petik
	$nama=mysqli_real_escape_string($koneksi, $_POST['nama']); 
	$alamat=htmlspecialchars($_POST['alamat']); //mengabaikan tag html; 
	$kecamatan=htmlspecialchars($_POST['kecamatan']);
	$usaha=htmlspecialchars($_POST['usaha']);
	$jenis_usaha=htmlspecialchars($_POST['jenis_usaha']);
	$modal=$_POST['modal'];
	$permasalahan=htmlspecialchars($_POST['permasalahan']);
	$pemecahan=htmlspecialchars($_POST['pemecahan']);
	$query=mysqli_query($koneksi, 
		"INSERT INTO data_ukm VALUES 
		('','$nama','$alamat','$kecamatan','$usaha','$jenis_usaha','$modal','$permasalahan','$pemecahan')
		");
	$sukses=mysqli_affected_rows($koneksi);
	if($sukses > 0){
		echo "<script>alert('Data Berhasil di Tambah');
			window.location.href='?menu=data_anggota_ukm';
		</script>";
	}else{
		echo "<script>alert('Data GAGAL di Tambah');
			window.location.href='?menu=data_anggota_ukm';
		</script>"; 
	}
}
?>
<?php 
break;
case "edit":
	//mengambil id yang dikirim melalui URL..
	$id=$_GET['id'];
	//query ke tabel sesuai dengan ID yang ada di URL
    $edit=mysqli_query($koneksi,"SELECT * FROM data_ukm WHERE id_data_ukm='$id'");
    $d=mysqli_fetch_array($edit);
?>
<h1 class="text-center" style="margin-top:60px;"> Edit Halaman Data Pemilik UKM</h1>
<hr/>
<div class="row">
	<div class="col-sm-4">
		<form method="POST">
			<input type="hidden" name="id" value="<?=$d['id_data_ukm'];?>" />
			<div class="form-group">
				<label for="nama">Nama</label><br/>
				<input type="text" class="form-control" name="nama" id="nama" value="<?=$d['nama'];?>" required placeholder="Tulis Nama" autocomplete="off" />
			</div>
			<div class="form-group">
				<label for="alamat">Alamat</label><br/>
				<input type="text" class="form-control"  name="alamat" id="alamat" value="<?=$d['alamat'];?>"/>
			</div>
			<div class="form-group">
				<label for="kecamatan">Kecamatan</label><br/>
				<input type="text" class="form-control"  name="kecamatan" id="kecamatan" value="<?=$d['kecamatan'];?>"/>
			</div>
			<div class="form-group">
				<label for="usaha">Usaha</label><br/>
				<input type="text" class="form-control"  name="usaha" id="usaha" value="<?=$d['usaha'];?>"/>
			</div>
			<div class="form-group">
				<label for="jenis_usaha">Jenis Usaha</label><br/>
				<input type="text" class="form-control"  name="jenis_usaha" id="jenis_usaha" value="<?=$d['jenis_usaha'];?>"/>
			</div>
			<div class="form-group">
				<label for="modal">Modal</label><br/>
				<input type="number" class="form-control" name="modal" id="modal" value="<?=$d['modal'];?>" min="1000000" max="1000000000000000" required autocomplete="off"/>
			</div>
			<div class="form-group">
				<label for="permasalahan">Permasalahan</label><br/>
				<input type="text" class="form-control"  name="permasalahan" id="permasalahan" value="<?=$d['permasalahan'];?>"/>
			</div>
			<div class="form-group">
				<label for="pemecahan">Solusi</label><br/>
				<input type="text" class="form-control"  name="pemecahan" id="pemecahan" value="<?=$d['pemecahan'];?>"/>
			</div>			
			<button type="submit" name="submit" class="btn btn-primary">Edi Data</button>
			<a href="?menu=data_anggota_ukm" class="btn btn-info">Kembali</a>
		</form>
	</div>
</div> <!-- end row -->
<?php 
if(isset($_POST['submit'])){ //jika tombol submit di klik
	//ambil data dari form input
	$id=$_POST['id'];
	$nama=mysqli_real_escape_string($koneksi, $_POST['nama']); //mengabaikan tanda petik
	$alamat=htmlspecialchars($_POST['alamat']); //mengabaikan tag html;
	$kecamatan=$_POST['kecamatan'];
	$usaha=$_POST['usaha'];
	$jenis_usaha=$_POST['jenis_usaha'];
	$modal=$_POST['modal'];
	$permasalahan=$_POST['permasalahan'];
	$pemecahan=$_POST['pemecahan'];
	$query=mysqli_query($koneksi, "UPDATE data_ukm SET 
	nama='$nama', alamat='$alamat', kecamatan='$kecamatan',usaha='$usaha',jenis_usaha='$jenis_usaha', modal='$modal',permasalahan='$permasalahan',pemecahan='$pemecahan' WHERE id_data_ukm='$id' ");
	$sukses=mysqli_affected_rows($koneksi);
	if($sukses > 0){
		echo "<script>alert('Data Berhasil di UBAH');
			window.location.href='?menu=data_anggota_ukm';
		</script>";
	}else{
		echo "<script>alert('Data GAGAL di UBAH');
			window.location.href='?menu=data_anggota_ukm';
		</script>"; 
	}
}
break;
case "hapus":
  $query=mysqli_query($koneksi,"select id_data_ukm from data_ukm where id_data_ukm='$_GET[id]'");
  $cek=mysqli_num_rows($query);
  if($cek == 0){
	echo "<script>alert('Hapus Data Gagal, Data Tidak Ditemukan');
      window.location=('?menu=data_anggota_ukm')</script>";
  }else{
	$hapus=mysqli_query($koneksi,"DELETE FROM data_ukm WHERE id_data_ukm='$_GET[id]'");
	if($hapus){
      echo "<script>
      window.location=('?menu=data_anggota_ukm')</script>";
    }else{
      echo "<script>alert('Hapus Data Gagal');
      window.location=('?menu=data_anggota_ukm')</script>";
    }
  } 
break;
}