<?php
include "koneksi.php";
$action=isset($_GET['submenu'])? $_GET['submenu'] :'';
switch($action){
default:
}
?>

  <h3><i class="fa-solid fa-house-chimney mr-2" style="margin-top:50px;"></i>  Beranda</h3><hr>
  <div class="row text-white" >
    <div class="card bg-info ml-4" style="width: 27rem; ">
      <div class="card-body">
        <div class="car-body-icon">
          <i class="fa-solid fa-folder"></i>
        </div>
        <h5 class="card-title">TAMPILKAN DATA UKM</h5>
        <!-- menampilkan data -->
        <?php $jumlah = mysqli_query($koneksi, "SELECT COUNT(id_data_ukm) AS jumlah FROM data_ukm;");
              $data = mysqli_fetch_assoc($jumlah);
        ?>
        <div class="display-4"> <?= $data['jumlah'] ?> </div>
        <a href="admin.php?menu=data_anggota_ukm"><p class="card-text text-white">Lihat Datail>> <i class="fas fa-angel-double-right ml-2"></i></p></a>
      </div>
    </div>
    <div class="card bg-success ml-4" style="width: 27rem;">
      <div class="card-body">
        <div class="car-body-icon">
          <i class="fa-solid fa-calendar-plus mr-2"></i>
        </div>
        <h5 class="card-title">TAMBAH DATA UKM</h5>
        <!-- menampilkan data -->
        <div class="display-4"> + </div>
          <a href="admin.php?menu=data_anggota_ukm&submenu=tambah"><p class="card-text text-white">Input>> <i class="fas fa-angel-double-right ml-2"></i></p></a>
        </div>
      </div>
      <!-- <div class="card bg-danger ml-4" style="width: 18rem;"> -->
        <!-- <div class="card-body">
          <div class="car-body-icon">
            <i class="fa-solid fa-pen-to-square"></i> 
          </div>
          <h5 class="card-title">EDIT DATA UKM</h5> -->
          <!-- menampilkan data -->
          <!-- <div class="display-4">  </div>
          <a href=""><p class="card-text text-white">Lihat Datail>> <i class="fas fa-angel-double-right ml-2"></i></p></a>
        </div>
      </div>
    </div> -->
    <!-- Sosmed -->
    <div class="row mt-4 ">
      <div class="card ml-4 text-white text-center" style=" width:18rem;">
        <div class="card-header bg-danger display-4 pt-2 pb-2s">
          <i class="fa-brands fa-instagram"></i>
        </div>
        <div class="card-body">
          <h5 class="card-title text-danger">INSTAGRAM</h5>
          <a href="https://www.instagram.com" class="btn btn-danger"> FOLLOW</a>
        </div>
      </div>
      <div class="card ml-4 text-white text-center" style=" width:18rem;">
        <div class="card-header bg-info display-4 pt-2 pb-2s">
          <i class="fa-brands fa-facebook-f"></i>
        </div>
        <div class="card-body">
          <h5 class="card-title text-info">FACEBOOK</h5>
          <a href="https://www.facebook.com" class="btn btn-info">LIKE</a>
        </div>
      </div>
      <div class="card ml-4 text-white text-center" style=" width:18rem;">
        <div class="card-header bg-primary display-4 pt-2 pb-2s">
          <i class="fa-brands fa-twitter"></i>
        </div>
        <div class="card-body">
          <h5 class="card-title text-primary">TWITTER</h5>
          <a href="https://twitter.com" class="btn btn-primary"> FOLLOW</a>
        </div>
      </div>
    </div>
  </div>