<br>
<div class="jumbotron jumbotron-fluid ">
  <div class="container text-center" >
    <img src="././gambar/unira.png" width="150" class="rounded-circle">
    <h1 class="display-4 "> <b> MAHASISWA UNIRA </b></h1>
    <p class="lead" >Tugas Project Akhir Pemrograman Web Teknik Informatika Universitas Madura</p>
    <p style= "text-center">Nama Kelompok</p>
    <p>Sukron Katsir, Dewa Pramudya H, Syakirun Niam</p>
  </div>
</div>
<div class="container">
    <div class="row">
        <div class="col text-center">
            <h1>About</h1>
        </div>
    </div>
    <div class="row text-center">
        <div class="col">
            <p>Aplikasi SIUKM Merupakan aplikasi pencatatan sebuah data para pelaku Usaha Kecil Menengah
                yang bisa memudahkan para pegawai UKM lebih mudah dalam pencarian data para
                pelaku Usaha Kecil Menengah di Area Pamekasan
            </p>
        </div>
        <div class="col">
            <p>Aplikasi SIUKM Merupakan tugas akhir dari praktikum Pemograman Web yang di ampu oleh
                Ibu Nuri Islamy Santoso,S.Kom dan yang mana dosen pengajar matakuliah Pemrograman Web
                Bapak Abd.Wahab Syahroni,S.Kom,M.Kom
            </p>
        </div>
    </div>
</div>


