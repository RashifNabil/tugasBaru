-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Jul 2022 pada 09.16
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `siukm`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_ukm`
--

CREATE TABLE `data_ukm` (
  `id_data_ukm` int(11) NOT NULL,
  `nama` varchar(75) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `kecamatan` varchar(50) NOT NULL,
  `usaha` varchar(50) NOT NULL,
  `jenis_usaha` varchar(50) NOT NULL,
  `modal` int(50) NOT NULL,
  `permasalahan` varchar(100) NOT NULL,
  `pemecahan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data_ukm`
--

INSERT INTO `data_ukm` (`id_data_ukm`, `nama`, `alamat`, `kecamatan`, `usaha`, `jenis_usaha`, `modal`, `permasalahan`, `pemecahan`) VALUES
(18, 'Moh. Suhar', 'Larangan Luar', 'Larangan', 'P.Ayam Potong', 'Industri', 30000000, 'adanya penyakit yang menyebabkan ayam mati', 'Memberi obat untuk perlindungan'),
(19, 'Rida\'i', 'Larangan Luar', 'Larangan', 'P.Ayam Potong', 'Industri', 40000000, 'Tempat yang kurang strategis', 'Mengurangi pencemaran lingkungan'),
(20, 'Sarbini', 'Larangan Luar', 'Larangan', 'Meubel', 'Industri', 10000000, 'pasar yang kurang luas', 'Mencari peluang pasar'),
(21, 'toja', 'larangan luar', 'larangan', 'meubel', 'industri', 6000000, 'saingan banyak', 'menjaga mutu'),
(22, 'hamiyah', 'larangan luar', 'larangan', 'produksi keripik', 'industri', 200000, 'pasaran yang sempit', 'berinovasi'),
(23, 'rusli', 'larangan luar', 'larangan', 'p.ayam potong', 'industri', 55000, 'penyakit ayam', 'memberi obat untuk perlindungan'),
(24, 'sari', 'larangan luar', 'larangan', 'meubel', 'industri', 10000000, 'pasaran yang kurang luas', 'mencari peluang pasar'),
(25, 'sawar', 'larangan luar', 'larangan', 'p. ayam petelur', 'industri', 43000000, 'permintaan telur semakin berkurang', 'mencari cara untuk memperluas pasar'),
(26, 'mashodi', 'larangan luar', 'larangan', 'p. ayam petelur', 'industri', 35000000, 'pasar yang sudah afkir', 'mencari pelanggan yang menjual daging ayam'),
(27, 'hambali', 'larangan luar', 'larangan', 'ayam petelur', 'industri', 60000000, 'permintaaan telur semakin berkurang', 'mencari cara untuk memperluas pasar'),
(28, 'tayyib', 'larangan luar', 'larangan', 'p. ayam petelur', 'industri', 60000000, 'harga pasar terus naik', '-'),
(29, 'satrawi', 'larangan luar', 'larangan', 'p.ayam petelur', 'industri', 45000000, 'permintaan telur semakin berkurang', 'mencari cara memperluas pasar'),
(30, 'masruroh', 'larangan luar', 'larangan', 'produksi keripik', 'industri', 250000, 'pasaran yang sempit', 'berinovasi'),
(31, 'slami', 'larangan luar', 'larangan', 'p. ayam petelur', 'industri', 50000000, 'pasar ayam yang sudah afkir', 'mencari pelanggan yang berjual daging ayam'),
(32, 'hosnan', 'larangan luar', 'larangan', 'p. ayam petelur', 'industri', 75000000, 'permitaan telur semakin berkurang', 'mencari cara memperluas pasar');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_login`
--

CREATE TABLE `tbl_login` (
  `id_login` int(11) NOT NULL,
  `username` varchar(75) NOT NULL,
  `password` varchar(75) NOT NULL,
  `nama_lengkap` varchar(75) NOT NULL,
  `status_login` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_login`
--

INSERT INTO `tbl_login` (`id_login`, `username`, `password`, `nama_lengkap`, `status_login`) VALUES
(2, 'admin', '21232F297A57A5A743894A0E4A801FC3', 'Admin SIUKM', 0),
(8, 'umar', '202cb962ac59075b964b07152d234b70', 'admin', 0),
(9, 'admin', '202cb962ac59075b964b07152d234b70', 'admin', 0),
(10, 'dewa', '202cb962ac59075b964b07152d234b70', 'dewa', 0);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `data_ukm`
--
ALTER TABLE `data_ukm`
  ADD PRIMARY KEY (`id_data_ukm`);

--
-- Indeks untuk tabel `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`id_login`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `data_ukm`
--
ALTER TABLE `data_ukm`
  MODIFY `id_data_ukm` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT untuk tabel `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `id_login` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
